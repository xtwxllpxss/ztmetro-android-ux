# ztmetro-font — systemless Selawik (Segoe UI metric-compatible) sans-serif

A Magisk module that makes **Selawik 1.01** the phone's default `sans-serif` font
without rebuilding LineageOS. It targets **Android 15/16** (LineageOS 23.2 on
`ugglite`), where `SystemFonts` reads `/system/etc/font_fallback.xml` and
`/system/etc/fonts.xml` is the legacy/Skia config.

Selawik is Microsoft's OFL-licensed, metric-compatible Segoe UI substitute; the
ztmetro tokens already name it as the free fallback after Segoe UI. No Segoe UI file
is included. The source repo's `fonts/selawik/README.md` describes a local,
user-supplied substitution; this zip ships `Selawik-OFL.txt` and
`Selawik-ATTRIBUTION.md`.

## Install

```sh
adb push ztmetro-font-1.0.0.zip /sdcard/
# Magisk app -> Modules -> Install from storage -> ztmetro-font-1.0.0.zip
# or:
adb shell su -c "magisk --install-module /sdcard/ztmetro-font-1.0.0.zip"
adb reboot
```

The installer runs on the device, reads the **live** config, and aborts (installing
nothing) if the file is not the expected Android 15/16 layout. No reboot is needed to
build the module; a reboot is needed to mount it.

## What it changes

| path | change |
|---|---|
| `/system/etc/font_fallback.xml` (Android 15+ primary) | `sans-serif` family replaced by 20 static Selawik entries (10 weights × normal/italic); every other family, fallback and alias copied byte-for-byte |
| `/system/etc/fonts.xml` (legacy, Skia/native/WebView) | same replacement, same fragment |
| `/system/fonts/Selawik-{Light,Semilight,Regular,Semibold,Bold}.ttf` | five new files |

Weight map in both configs:

| Android weight | Selawik face |
|---|---|
| 100, 200, 300 | Light |
| 350 | Semilight |
| 400 | Regular |
| 500, 600 | Semibold (500 is `sans-serif-medium`) |
| 700, 800, 900 | Bold |

It does **not** touch emoji, CJK, monospace, serif, `sans-serif-condensed`, symbols
or any other font file. Alias lines (`sans-serif-light`, `sans-serif-medium`, …) are
left intact and re-point at the rewritten family automatically.

## Known limitations

- **Selawik 1.01 is Latin-only** (347 codepoints; no Cyrillic/Greek). Cyrillic and
  Greek glyphs fall through to `NotoSansCJK-Regular.ttc`, so a Russian UI mixes
  Selawik Latin with Noto Cyrillic. Use a locally supplied Segoe UI (same file names,
  own licence) if you need one face for both.
- **No italic faces** in Selawik 1.01. The config's `style="italic"` entries point at
  the upright face, so italic text is expected to render upright instead of falling
  back to Roboto `[E]`. This is deliberate (one family, one set of metrics) but it is
  a real loss.
- Apps that bundle their own fonts ignore this (Telegram's medium/extrabold/italic
  headers, games, many Flutter/RN apps). See `evidence/font-module/REPORT.md`.
- A `/product/etc/fonts_customization.xml` that defines a named `sans-serif` family
  would override this module; check it on the device.
- Effects after a LineageOS OTA: re-flash the module (Magisk modules generally
  survive; re-check).

## Safety / recovery

The module only overlays files; `/system` is never written. The installer validates
the produced XML (well-formedness, family/alias counts, 20 Selawik entries, and a
byte-comparison of everything outside the family) and aborts on any mismatch.

If the device fails to boot after installing:

1. **Magisk safe mode**: hold **Volume Down** while booting (Magisk disables all
   modules for that boot); remove/disable `ztmetro-font`, reboot.
2. With adb access: `adb shell su -c "touch /data/adb/modules/ztmetro-font/disable"`
   then reboot; or `adb shell su -c "magisk --remove-modules"` and reboot.
3. Recovery/TWRP: delete `/data/adb/modules/ztmetro-font/` or create the empty file
   `disable` inside it.
4. Worst case: the stock font config is untouched on disk; removing the module
   directory restores stock fonts on the next boot.

A malformed font config is the only boot risk; that is why the installer refuses to
write one it cannot validate.

## Files in this source tree

```
modules/ztmetro-font/
  module.prop            Magisk identity
  customize.sh           installer: locate live config, call rewrite, validate
  rewrite-fonts.sh       POSIX sh: splice + validate (also runs on a Linux host)
  verify-xml.awk         tag-balance XML check used on-device
  fonts.fragment         the only thing that replaces the sans-serif family
  README.md              this file
```

The built zip adds `system/fonts/Selawik-*.ttf`, the generated
`system/etc/font_fallback.xml` + `system/etc/fonts.xml`, `Selawik-OFL.txt` and
`Selawik-ATTRIBUTION.md`.

## Build

```sh
scripts/build-font-module.sh
# -> artifacts/ztmetro-font-1.0.0.zip + sha256, module file list validated
```

No Android SDK, Gradle or device is needed: `bash`, `zip`, `unzip`, `awk`, `sh` and
(optionally) `python3` for the full XML parse. The script also replays the splice
against the checked-in AOSP 16 fixtures and parses the result before building.
